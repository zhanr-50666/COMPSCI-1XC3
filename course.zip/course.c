/**
  * @file     	course.c
  * @date    	12-04-2022
  * @brief   	course info
  * @attention
  */  

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief		enroll student
 * @param[in]	course : course manager pointer
 * @param[in]	student : student pointer
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief		print course info and student info
 * @param[in]	course : course manager pointer
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief		search the students with the best grades
 * @param[in]	course : course manager pointer
 * @return		
 *	the students with the best grades
 */
Student* top_student(Course* course)
{
  /// if no student return NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  /// return student
  return student;
}

/**
 * @brief		Count the number of student passes and return the students who pass
 * @param[in]	course : course manager pointer
 * @param[in]	total_passing : size of student passes
 * @return		
 *	return the students who pass
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  /// alloc memory for student passes
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  /// count the number of student
  *total_passing = count;

  return passing;
}