var searchData=
[
  ['top_5fstudent_0',['top_student',['../course_8c.html#ac1d82150824c7ecd43bab36fb83cd779',1,'top_student(Course *course):&#160;course.c'],['../course_8h.html#ac1d82150824c7ecd43bab36fb83cd779',1,'top_student(Course *course):&#160;course.c']]],
  ['total_5fstudents_1',['total_students',['../struct__course.html#a6de820e9130cb18bb757b6f17df6c002',1,'_course']]]
];
